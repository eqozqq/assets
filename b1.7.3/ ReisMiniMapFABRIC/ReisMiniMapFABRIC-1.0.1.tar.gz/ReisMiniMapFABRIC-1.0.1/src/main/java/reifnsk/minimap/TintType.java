package reifnsk.minimap;

public enum TintType {
    NONE,
    GRASS,
    FOLIAGE,
    PINE,
    BIRCH,
    REDSTONE,
    GLASS,
    WATER,
    ETC;
}
