package reifnsk.minimap;

public interface GuiScreenInterface {
}
